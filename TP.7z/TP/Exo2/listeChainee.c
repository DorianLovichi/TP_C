#include <stdio.h>
#include <stdlib.h>

// Définition de la structure du noeud de la liste chaînée
typedef struct Noeud {
    int donnee;           // donnee de l'élément
    struct Noeud* suivant;  // pointeur vers le prochain noeud
} Noeud;

// Définition de la structure de la pile
typedef struct Pile {
    Noeud* sommet;  // pointeur vers le sommet de la pile
} Pile;

// Fonction pour créer une nouvelle pile (initialisation)
Pile* creerPile() {
    Pile* pile = (Pile*)malloc(sizeof(Pile));
    if (pile == NULL) {
        fprintf(stderr, "erreur lors de l'allocation de memoire pour la pile.\n");
        exit(EXIT_FAILURE);
    }
    pile->sommet = NULL;  // initialise le sommet de la pile à NULL (pile vide)
    return pile;
}

// Fonction pour tester si la pile est vide
int estVide(Pile* pile) {
    return pile->sommet == NULL;  // la pile est vide si le sommet est NULL
}

// Fonction pour empiler un nouvel élément de type entier
void empiler(Pile* pile, int valeur) {
    // crée un nouveau noeud pour la nouvelle valeur
    Noeud* nouveauNoeud = (Noeud*)malloc(sizeof(Noeud));
    if (nouveauNoeud == NULL) {
        fprintf(stderr, "erreur lors de l'allocation de memoire pour le nouvel element.\n");
        exit(EXIT_FAILURE);
    }
    nouveauNoeud->donnee = valeur;      // assigner la valeur au noeud
    nouveauNoeud->suivant = pile->sommet; // le prochain noeud est l'ancien sommet de la pile
    pile->sommet = nouveauNoeud;       // met à jour le sommet de la pile
}

// Fonction pour récupérer la valeur de l'élément de sommet de pile
int sommet(Pile* pile) {
    if (estVide(pile)) {
        fprintf(stderr, "la pile est vide. impossible de recuperer la valeur du sommet.\n");
        exit(EXIT_FAILURE);
    }
    return pile->sommet->donnee;  // renvoie la valeur du sommet de la pile
}

// Fonction pour récupérer la valeur et enlever l'élément de sommet de pile
int depiler(Pile* pile) {
    if (estVide(pile)) {
        fprintf(stderr, "la pile est vide. impossible de retirer un element.\n");
        exit(EXIT_FAILURE);
    }
    // récupère la valeur du sommet de la pile
    int valeur = pile->sommet->donnee;
    // déplace le sommet de la pile vers le noeud suivant
    Noeud* temp = pile->sommet;
    pile->sommet = pile->sommet->suivant;
    free(temp);  // libère la mémoire du noeud retiré
    return valeur;
}

// Fonction pour libérer la mémoire allouée à la pile
void detruirePile(Pile* pile) {
    while (!estVide(pile)) {
        depiler(pile);  // vide la pile
    }
    free(pile);  // libère la mémoire de la structure de la pile
}

// Fonction principale (exemple d'utilisation)
int main() {
    // création d'une nouvelle pile
    Pile* pile = creerPile();

    // teste si la pile est vide
    printf("la pile est vide : %s\n", estVide(pile) ? "oui" : "non");

    // empile des éléments
    empiler(pile, 10);
    empiler(pile, 20);
    empiler(pile, 30);

    // affiche la valeur du sommet de la pile sans la retirer
    printf("valeur du sommet de la pile : %d\n", sommet(pile));

    // retire et affiche les éléments de la pile
    while (!estVide(pile)) {
        printf("element retire de la pile : %d\n", depiler(pile));
    }

    // teste si la pile est vide après avoir retiré tous les éléments
    printf("la pile est vide : %s\n", estVide(pile) ? "oui" : "non");

    // libère la mémoire allouée à la pile
    detruirePile(pile);

    return 0;
}
